﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace GetShortestRoute.Controllers
{
    public class ShortestRouteController : ApiController
    {

        [Route("route/origin/{origin}/destination/{dest}")]
        [HttpGet]
        public HttpResponseMessage getShortestRoute(string origin, string dest)
        {
            Models.RouteRequest request = new Models.RouteRequest();
            Models.ShortestRoute ShortestRoute = new Models.ShortestRoute(request);

            ShortestRoute.Request(origin, dest);

            string response = ShortestRoute.Route;

            var resp = new HttpResponseMessage(HttpStatusCode.OK);
            resp.Content = new StringContent(response, System.Text.Encoding.UTF8, "text/plain");
            return resp;
            
        }
    }
}
