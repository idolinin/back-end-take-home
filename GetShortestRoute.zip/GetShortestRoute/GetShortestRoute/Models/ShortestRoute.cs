﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace GetShortestRoute.Models
{
    public class RouteRequest
    {
        string queryString = "";
        string connectionString = "Data Source=(local);Initial Catalog=TestDB;User Id=newuser;Password=newuser;";
        public RouteRequest()
        {
            
        }

        public void SetParameters(string origin, string destination)
        {
            queryString = string.Format("exec dbo.sp_GetShortestRoute '{0}','{1}'",origin,destination);
        }

        public string Read()
        {
            string response = "";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(queryString, connection);
                //command.Parameters.AddWithValue("@tPatSName", "Your-Parm-Value");
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                try
                {
                    while (reader.Read())
                    {
                        response = (string)reader["Response"];// etc
                    }
                }
                finally
                {
                    // Always call Close when done reading.
                    reader.Close();
                }
            }

            return response;
        }

    }
    public class ShortestRoute
    {
        public string Route { get; set; }
        public RouteRequest request;
        public ShortestRoute(RouteRequest req)
        {
            request = req;
        }
        public void Request(string origin, string destination)
        {
            request.SetParameters(origin, destination);
            Route = request.Read();
        }
    }
}